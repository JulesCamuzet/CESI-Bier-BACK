<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
       
    </head>
    <body>
        <span>test</span>
    </body>
</html>
<?php /**PATH D:\xampp\htdocs\CESI-Bier-BACK\resources\views/welcome.blade.php ENDPATH**/ ?>