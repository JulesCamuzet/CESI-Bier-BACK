<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Support\Str;

class Product extends Model
{
    use HasFactory;

    /**
     * Get the order items for the product.
     */
    public function orderItems()
    {
        return $this->hasMany(OrderItem::class);
    }

    /**
     * Transforme tous les attributs du modèle en camelCase.
     *
     * @param  array  $attributes
     * @return array
     */
    public function getAttributes()
    {
        $attributes = parent::getAttributes();

        // Convertir toutes les clés des attributs en camelCase
        return $this->convertKeysToCamelCase($attributes);
    }

    /**
     * Convertir les clés de snake_case en camelCase.
     *
     * @param  array  $attributes
     * @return array
     */
    public function convertKeysToCamelCase(array $attributes)
    {
        $converted = [];
        foreach ($attributes as $key => $value) {
            $converted[Str::camel($key)] = $value;
        }
        return $converted;
    }

    /**
     * Convertir les clés de snake_case en camelCase lors de la sérialisation JSON.
     *
     * @return mixed
     */
    public function jsonSerialize(): mixed
    {
        // Sérialiser le modèle avec des clés en camelCase
        return $this->convertKeysToCamelCase(parent::jsonSerialize());
    }
    public function orders()
    {
        return $this->belongsToMany(Order::class, 'order_products')
            ->withPivot('quantity');
    }

}
